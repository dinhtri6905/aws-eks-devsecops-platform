kustomize/base/security/
│
├── kustomization.yaml              # root — list tất cả resources
│
├── opa-gatekeeper/
│   ├── kustomization.yaml
│   ├── namespace.yaml              # wave 0
│   ├── helmrelease.yaml            # wave 0 — install Gatekeeper via Helm
│   ├── templates/
│   │   ├── kustomization.yaml
│   │   ├── k8srequiredlabels.yaml       # wave 1
│   │   ├── k8srequiredresources.yaml    # wave 1
│   │   ├── k8snonroot.yaml              # wave 1
│   │   └── k8sdisallowprivileged.yaml   # wave 1
│   └── constraints/
│       ├── kustomization.yaml
│       ├── require-labels.yaml          # wave 2
│       ├── require-resource-limits.yaml # wave 2
│       ├── require-non-root.yaml        # wave 2
│       └── disallow-privileged.yaml     # wave 2
│
└── falco/
    ├── kustomization.yaml
    ├── namespace.yaml              # wave 0
    ├── helmrelease.yaml            # wave 0 — install Falco via Helm
    └── custom-rules/
        ├── kustomization.yaml
        └── custom-rules.yaml       # wave 1 — ConfigMap với custom rules